import "./ProductSell.css";

function ProductSell() {
  return (
    <div className="productSell">
      <h2>Product Sell</h2>
      <div className="productSell__container">
        <div className="productSell__list">
          <div className="productSell__item">
            <img
              src="https://img.pikbest.com/origin/08/99/02/375pIkbEsTDRx.jpg!w700wp"
              alt="Product 1"
              width="80"
              height="80"
            />
            <div>
              <p className="bold-text">Abstract 3D</p>
              <span className="gray-text">Lorium ipsum dolor sit amet, consectatur adipiscing elit.</span>
            </div>
          </div>
          <div className="productSell__item">
            <img
              src="https://cdn.mos.cms.futurecdn.net/ZcD9zyBoBHt6ATTFmZHr5B.jpg"
              alt="Product 2"
              width="80"
              height="80"
            />
            <div>
              <p className="bold-text">Sarphens Illustration</p>
              <span className="gray-text">Lorium ipsum dolor sit amet, consectatur adipiscing elit.</span>
            </div>
          </div>
        </div>
        <div className="productSell__right">
          <div className="productSell__search">
            <input type="text" placeholder="Search" />
            <button className="productSell__button">Last 30 days ▼</button>
          </div>
          <div className="productSell__stats">
            <div>
              <p className="bold-text">Stock</p>
              <span>32 in stock</span>
            </div>
            <div>
              <p className="bold-text">Price</p>
              <span>$45.99</span>
            </div>
            <div>
              <p className="bold-text">Total Sales</p>
              <span>20</span>
            </div>
            <div>
              <span>32 in stock</span>
            </div>
            <div>
              <span>$45.99</span>
            </div>
            <div>
              <span>20</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductSell;
