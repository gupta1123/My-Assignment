import React, { useState } from "react";
import "./Dashboard.css"; // Import Dashboard.css for the styling
import Overview from "../Overview/Overview";
import Customers from "../Customers/Customers";
import ProductSell from "../ProductSell/ProductSell";

function Dashboard() {
  const [isCustomersHovered, setIsCustomersHovered] = useState(false);

  const handleCustomersClick = () => {
    setIsCustomersHovered(!isCustomersHovered);
  };

  return (
    <div className="dashboard">
      <div className="dashboard__header">
        <h1>Hello Shahrukh 👋</h1>
        <input type="text" placeholder="Search" className="dashboard__search" />
      </div>

      <div className="dashboard__content">
        <div className="card-container">
          <div className="card green">
            <div className="icon">
              <i className="fas fa-dollar-sign"></i>
            </div>
            <h2>Earning</h2>
            <p>$198K</p>
            <span className="green-text">+3.7% this month</span>
          </div>
          <div className="card purple">
            <div className="icon">
              <i className="fas fa-sticky-note"></i>
            </div>
            <h2>Orders</h2>
            <p>$2.4K</p>
            <span className="purple-text">+2% this month</span>
          </div>
          <div className="card blue">
            <div className="icon">
              <i className="fas fa-balance-scale"></i>
            </div>
            <h2>Balance</h2>
            <p>$2.4K</p>
            <span className="blue-text">+2% this month</span>
          </div>
          <div className="card red">
            <div className="icon">
              <i className="fas fa-shopping-bag"></i>
            </div>
            <h2>Total Sales</h2>
            <p>$89K</p>
            <span className="red-text">+11% this week</span>
          </div>
        </div>
        <div
          className={`overview-product-customer-container ${
            isCustomersHovered ? "customers-hovered" : ""
          }`}
        >
          <div className="overview-card">
            <Overview />
          </div>
          {/* Customers card */}
          <div
            className={`customer-card ${isCustomersHovered ? "hovered" : ""}`}
          >
            <Customers />
          </div>
        </div>
        <div className="product-sell-container">
          <ProductSell />
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
