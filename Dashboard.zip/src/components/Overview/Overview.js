import React from "react";
import "./Overview.css";

function Overview() {
  return (
    <div className="overview-container">
      <div className="overview">
        <div className="overview-header">
          <div>
            <h2>Overview</h2>
            <span className="monthly-earning">Monthly Earning</span>
          </div>
          <div className="quarterly-section">
            <span className="quarterly-text">Quarterly</span>
            <button className="quarterly-dropdown">&#x25BC;</button>
          </div>
        </div>
        <div className="overview__graph">
          <div className="bar" style={{ height: "50%" }}></div>
          <div className="bar" style={{ height: "20%" }}></div>
          <div className="bar" style={{ height: "60%" }}></div>
          <div className="bar" style={{ height: "40%" }}></div>
          <div className="bar" style={{ height: "50%" }}></div>
          <div className="bar" style={{ height: "30%" }}></div>
          <div className="bar" style={{ height: "50%" }}></div>
          <div className="bar" style={{ height: "90%" }}></div>
          <div className="bar" style={{ height: "80%" }}></div>
          <div className="bar" style={{ height: "70%" }}></div>
          <div className="bar" style={{ height: "50%" }}></div>
          <div className="bar" style={{ height: "60%" }}></div>
        </div>
      </div>
    </div>
  );
}

export default Overview;
