import React from "react";
import "./Sidebar.css";
import { FaHome, FaBox, FaUsers, FaDollarSign, FaBullhorn, FaQuestionCircle, FaChartBar } from "react-icons/fa";

function Sidebar() {
  return (
    <div className="sidebar">
      <div className="sidebar__item">
        <span className="sidebar__icon">
          <FaHome />
        </span>
        <span className="sidebar__title">Dashboard</span>
      </div>
      <div className="sidebar__item">
        <span className="sidebar__icon">
          <FaBox />
        </span>
        <span className="sidebar__title">Product</span>
      </div>
      <div className="sidebar__item">
        <span className="sidebar__icon">
          <FaUsers />
        </span>
        <span className="sidebar__title">Customers</span>
      </div>
      <div className="sidebar__item">
        <span className="sidebar__icon">
          <FaDollarSign />
        </span>
        <span className="sidebar__title">Income</span>
      </div>
      <div className="sidebar__item">
        <span className="sidebar__icon">
          <FaBullhorn />
        </span>
        <span className="sidebar__title">Promote</span>
      </div>
      <div className="sidebar__item">
        <span className="sidebar__icon">
          <FaQuestionCircle />
        </span>
        <span className="sidebar__title">Help</span>
      </div>
      <div className="sidebar__item">
        <span className="sidebar__icon">
          <FaChartBar />
        </span>
        <span className="sidebar__title">Reports</span>
      </div>
      <div className="sidebar__footer">
        <div className="sidebar__footer-circle">
          <div className="circle-image">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS71Q4oSAZnP4yOCRmqxfvVLbnq6Ug5E_jcig&usqp=CAU" alt="Circle" />
          </div>
          <span className="sidebar__footer-title">Evano</span>
        </div>
        <span className="sidebar__footer-subtitle">Project Manager</span>
      </div>
    </div>
  );
}

export default Sidebar;
