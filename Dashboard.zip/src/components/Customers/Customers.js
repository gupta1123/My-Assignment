// Customers.js

import React from "react";
import "./Customers.css";

function Customers() {
  return (
    <div className="customers-card">
      <header>
        <h2>Customers</h2>
        <p>Customers that buy products</p>
      </header>
      <div className="pie-container">
        <div className="pie-chart">
          <div className="slice"></div>
          <div className="slice"></div>
          <div className="slice"></div>
          <div className="slice"></div>
          <div className="slice"></div>
          <div className="slice"></div>
          <div className="slice"></div>
          <div className="slice"></div>
          <div className="slice"></div>
          <div className="slice"></div>
          <div className="slice"></div>
          <div className="slice"></div>
        </div>
        <div className="chart-info">
          <span>65% Total New Customers</span>
        </div>
      </div>
    </div>
  );
}

export default Customers;
